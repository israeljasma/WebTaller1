#!/bin/bash

python servidor_demo.py
